package com.example.android.botanica;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    /**
     * This method is called when the Submit button is clicked.
     */
    public void submitQuiz(View view) {

        // Figure out if the user has answered QUESTION 1
        RadioButton energyRadioButton = findViewById(R.id.energy_d);
        boolean answerEnergy = energyRadioButton.isChecked();

        // Figure out if the user has answered QUESTION 2
        RadioButton cocoabeansRadioButton = findViewById(R.id.cocoabeans_d);
        boolean answerCocoabeans = cocoabeansRadioButton.isChecked();

        // Figure out if the user has answered QUESTION 3
        RadioButton fernRadioButton = findViewById(R.id.fern_d);
        boolean answerFern = fernRadioButton.isChecked();

        // Figure out if the user has answered QUESTION 4
        RadioButton abacusRadioButton = findViewById(R.id.abacus_c);
        boolean answerAbacus = abacusRadioButton.isChecked();

        // Figure out if the user has answered QUESTION 5
        EditText sunEditText = findViewById(R.id.sun_name_field);
        String answerSun = sunEditText.getText().toString();


        // Figure out if the user has answered QUESTION 6
        CheckBox yewCheckBox = findViewById(R.id.yew_checkbox);
        boolean answerYew = yewCheckBox.isChecked();

        CheckBox tobaccoCheckBox = findViewById(R.id.tobacco_checkbox);
        boolean answerTobacco = tobaccoCheckBox.isChecked();

        CheckBox pinetreeCheckBox = findViewById(R.id.pinetree_checkbox);
        boolean answerPinetree = pinetreeCheckBox.isChecked();

        // Find the username
        EditText userNameField = findViewById(R.id.user_name);
        String name = userNameField.getText().toString();

        // Display a Toast message about the user's result
        if (!name.equals("")) {
            // Calculate the score
            int score = calculateScore(answerEnergy, answerCocoabeans, answerFern, answerAbacus, answerSun, answerYew, answerTobacco, answerPinetree);

            // Display the score summary
            String scoreMessage = createScoreSummary(name, score);
            displayMessage(scoreMessage);

            // Display a Toast message with score
            Toast.makeText(this, scoreMessage, Toast.LENGTH_LONG).show();


            if (score == 0) {
                Toast.makeText(this, "Come on," + name + "! You scored 0 points. Try again!", Toast.LENGTH_LONG).show();
            } else if (score <= 3) {
                Toast.makeText(this, "Not bad but you can do better, " + name + "! Your score is: " + score + "/7. Try again!", Toast.LENGTH_LONG).show();
            } else if (score == 7) {
                Toast.makeText(this, "Are you a biologist, " + name + "? Your score is: " + score + "/7. Congratulations!", Toast.LENGTH_LONG).show();
            } else if (score >= 4) {
                Toast.makeText(this, "Very good, " + name + ". Your score is: " + score + "/7. You answered more than half of the question right.", Toast.LENGTH_LONG).show();
            }

        } else {
            Toast.makeText(this, "You need to answer the last question.", Toast.LENGTH_LONG).show();
        }
    }

    /**
     * Calculate the score
     *
     * @param answerEnergy     is whether or not the user get the right answer
     * @param answerCocoabeans is whether or not the user get the right answer
     * @param answerFern       is whether or not the user get the right answer
     * @param answerAbacus     is whether or not the user get the right answer
     * @param answerYew        is whether or not the user get the right answer
     * @param answerTobacco    is whether or not the user get the right answer
     * @param answerPinetree   is whether or not the user get the right answer
     * @return total score
     */
    private int calculateScore(boolean answerEnergy, boolean answerCocoabeans, boolean answerFern, boolean answerAbacus, String answerSun, boolean answerYew, boolean answerTobacco, boolean answerPinetree) {
        int baseScore = 0;
        // Add 1 point to right answer - QUESTION 1

        if (answerEnergy) {
            baseScore += 1;
        }
        // Add 1 point to right answer - QUESTION 2
        if (answerCocoabeans) {
            baseScore += 1;
        }
        // Add 1 point to right answer - QUESTION 3
        if (answerFern) {
            baseScore += 1;
        }
        // Add 1 point to right answer - QUESTION 4
        if (answerAbacus) {
            baseScore += 1;
        }
        // Add 1 point to right answer - QUESTION 5
        if (answerSun.equalsIgnoreCase("Sun")) {
            baseScore += 1;
        }
        // Add 1+1 point to right answer - QUESTION 6
        if (answerYew) {
            baseScore += 1;
        }
        if (answerTobacco) {
            baseScore += 1;
        }
        if ((answerPinetree) && (baseScore >= 1)) {
            baseScore -= 1;
        }


        return baseScore;
    }

    /**
     * Create summary of the Score.
     *
     * @param name  of the user
     * @param score of the quiz
     * @return text summary
     */
    private String createScoreSummary(String name, int score) {
        String scoreMessage = "Let's see your result, " + name + "!";
        scoreMessage += "\nYou've answered " + score + " / 7 topics correctly.";
        scoreMessage += "\n";
        scoreMessage += "\nQ.1 answer: Energy, 1 point";
        scoreMessage += "\nQ.2 answer: Cocoabeans, 1 point";
        scoreMessage += "\nQ.3 answer: Fern, 1 point";
        scoreMessage += "\nQ.4 answer: Abacus, 1 point";
        scoreMessage += "\nQ.5 answer: Sun, 1 point";
        scoreMessage += "\nQ.6 answer: Yew and Tobacco, 2 points";
        return scoreMessage;

    }

    /**
     * This method displays the given Score on the screen.
     */
    private void displayMessage(String message) {
        TextView scoreSummaryTextView = findViewById(R.id.score_summary_text_view);
        scoreSummaryTextView.setText(message);
    }

    /**
     * This method will clear the quiz when the Reset button is clicked
     */

    public void resetQuiz(View view) {
        // Reset QUESTION 1
        RadioGroup question1RadioGroup = findViewById(R.id.question1);
        question1RadioGroup.clearCheck();

        // Reset QUESTION 2
        RadioGroup question2RadioGroup = findViewById(R.id.question2);
        question2RadioGroup.clearCheck();

        // Reset QUESTION 3
        RadioGroup question3RadioGroup = findViewById(R.id.question3);
        question3RadioGroup.clearCheck();

        // Reset QUESTION 4
        RadioGroup question4RadioGroup = findViewById(R.id.question4);
        question4RadioGroup.clearCheck();

        // Reset QUESTION 5
        EditText sunEditText = findViewById(R.id.sun_name_field);
        sunEditText.getText().clear();

        // Reset QUESTION 6
        CheckBox yewCheckBox = findViewById(R.id.yew_checkbox);
        yewCheckBox.setChecked(false);

        CheckBox tobaccoCheckBox = findViewById(R.id.tobacco_checkbox);
        tobaccoCheckBox.setChecked(false);

        CheckBox pinetreeCheckBox = findViewById(R.id.pinetree_checkbox);
        pinetreeCheckBox.setChecked(false);

        // Reset username
        EditText userNameField = findViewById(R.id.user_name);
        userNameField.getText().clear();

        // Reset the Score Summary and show a Toast message
        TextView scoreSummary = findViewById(R.id.score_summary_text_view);
        scoreSummary.setText("");

        Toast.makeText(this, "Botanica Quiz has been reset successfully.", Toast.LENGTH_LONG).show();

    }
}